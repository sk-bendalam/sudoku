import Frame from "@/components/frame/Frame";
import Image from "next/image";

export default function Home() {
  return <div className="text-white h-full ">
    home
    <Frame/>
    </div>;
}
