import React from 'react'

const Projects = () => {
  return (
    <div>Projects</div>
  )
}

export default Projects