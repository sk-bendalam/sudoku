"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import React, { useEffect, useState } from "react";
import { FaBars, FaTimes } from "react-icons/fa";
const Navbar = () => {
    const router = usePathname();
  const [showMenu, setShowMenu] = useState(false);
  useEffect(()=>{
    console.log(router)
  },[router])
  return (
    <nav className="flex flex-row justify-between gap-4 ">
      <div className="flex-[3] xl:flex-[4] select-none font-bold text-xl">Stack Developer</div>
      <div className="flex-1 justify-between gap-3 hidden sm:flex">
        <Link className={"hover:underline underline-offset-4 "+ `${router=="/"?"underline decoration-orange-300":""}`} href={"/"}>Home</Link>
        <Link className={"hover:underline underline-offset-4 "+ `${router=="/projects"?"underline decoration-orange-300":""}`} href={"/projects"}>Projects</Link>
        <Link className={"hover:underline underline-offset-4 "+ `${router=="/contact"?"underline decoration-orange-300":""}`} href={"/contact"}>Contact</Link>
      </div>
      <div className="flex-1 items-center justify-end gap-3 flex sm:hidden">
        {!showMenu && (
          <FaBars
            className="hover:cursor-pointer"
            onClick={() => setShowMenu((prev) => !prev)}
          />
        )}
        {showMenu && (
          <FaTimes
            className="hover:cursor-pointer"
            onClick={() => setShowMenu((prev) => !prev)}
          />
        )}
        {showMenu && (
          <div className="absolute top-8 bg-black">
            <ul>
              <div className="flex justify-end text-black text-lg h-4 px-1 select-none bg-white">
                ^
              </div>
              <div className="border border-dashed p-4">
                <li>
                  <Link onClick={() => setShowMenu((prev) => !prev)} href={"/"}>Home</Link>
                </li>
                <li>
                  <Link onClick={() => setShowMenu((prev) => !prev)} href={"/projects"}>Projects</Link>
                </li>
                <li>
                  <Link onClick={() => setShowMenu((prev) => !prev)} href={"/contact"}>Contact</Link>
                </li>
              </div>
            </ul>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
