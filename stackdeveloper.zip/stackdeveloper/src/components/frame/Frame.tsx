import Image from 'next/image'
import React from 'react'
import profileImg from "./profile.jpg"
const Frame = () => {
  return ( 


     <div>hello</div>
 
  
  )
}

export default Frame